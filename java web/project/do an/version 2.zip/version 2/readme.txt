bài làm vẫn còn rất nhiều chức năng chưa xử lý
giao diện đẹp :3
mới chỉ ở jsp/servlet
...