
package dto;

public class ChiTietDonHang {
    private int id_ddh;
    private int id_sp;
    private int soluong;
    private int gia;
    private DienThoai dienthoai;
    private Anh anh;

    public Anh getAnh() {
        return anh;
    }

    public void setAnh(Anh anh) {
        this.anh = anh;
    }
    
    public DienThoai getDienthoai() {
        return dienthoai;
    }

    public void setDienthoai(DienThoai dienthoai) {
        this.dienthoai = dienthoai;
    }

    public int getId_ddh() {
        return id_ddh;
    }

    public void setId_ddh(int id_ddh) {
        this.id_ddh = id_ddh;
    }

    public int getId_sp() {
        return id_sp;
    }

    public void setId_sp(int id_sp) {
        this.id_sp = id_sp;
    }


    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public int getGia() {
        return gia;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }
    
}
