/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.*;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import utils.DatabaseUtils;

/**
 *
 * @author Administrator
 */
public class DonHangDAO {

    public static ArrayList<DonHang> GetDonHang(String id) {
        ArrayList<DonHang> list = new ArrayList<DonHang>();
        DonHang dh = null;
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        String sql = "exec ViewDH @id_ddh=" + id;
        try {
            con = DatabaseUtils.getConnection();
            sta = con.createStatement();
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                dh = new DonHang();

                KhachHang kh = new KhachHang();
                kh.setTen(rs.getString("tenkh"));
                kh.setSdt(rs.getInt("sdt"));
                kh.setDiachi(rs.getString("diachi"));
                dh.setKhachhang(kh);

                NhanVien nv = new NhanVien();
                nv.setTen(rs.getString("tennv"));
                dh.setNhanvien(nv);

                dh.setId(rs.getInt("id"));
                dh.setNgaylap(rs.getDate("ngaylap"));
                dh.setTinhtrang(rs.getString("tinhtrang"));
                dh.setGhichu(rs.getString("ghichu"));
                
                NhaSanXuat nsx = new dto.NhaSanXuat();
                nsx.setId(rs.getInt("id_nsx"));
                nsx.setTen(rs.getString("ten"));
                dh.setNsx(nsx);

                ChiTietDonHang ct = new ChiTietDonHang();
                ct.setSoluong(rs.getInt("soluong"));
                ct.setId_sp(rs.getInt("id_sp"));
                dh.setCtdh(ct);
                
                DanhMuc dmuc = new DanhMuc();
                dmuc.setId(rs.getInt("id_dm"));
                dmuc.setTen(rs.getString("ten"));
                dh.setDm(dmuc);
                
                DienThoai dt = new DienThoai();
                dt.setId(rs.getInt("id"));
                dt.setTen(rs.getString("ten"));
                dt.setGia(rs.getInt("gia"));
                dt.setSoluong(rs.getInt("soluong"));
                dt.setTrongluong(rs.getString("trongluong"));
                dt.setROM(rs.getString("ROM"));
                dt.setRAM(rs.getString("RAM"));
                dt.setThenho(rs.getString("thenho"));
                dt.setCamera_truoc(rs.getString("camera_truoc"));
                dt.setCamera_sau(rs.getString("camera_sau"));
                dt.setPin(rs.getInt("pin"));
                dt.setBaohanh(rs.getString("baohanh"));
                dt.setBluetooth(rs.getInt("bluetooth"));
                dt.setCPU(rs.getString("CPU"));
                dt.setManhinh(rs.getString("manhinh"));
                dt.setStatus(rs.getInt("status"));
                dh.setDt(dt);
                
                list.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseResultSet(rs);
            DatabaseUtils.CloseStatement(sta);
            DatabaseUtils.CloseConnection(con);
        }
        return list;
    }

    public static ArrayList<DonHang> listDonHang() {
        ArrayList<DonHang> listDonHang = new ArrayList<DonHang>();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        DonHang dh = null;
        String sql = "exec ViewDetailsDH";
        try {
            con = DatabaseUtils.getConnection();
            sta = con.createStatement();
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                dh = new DonHang();

                KhachHang kh = new KhachHang();
                kh.setTen(rs.getString("tenkh"));
                kh.setDiachi(rs.getString("diachi"));
                dh.setKhachhang(kh);

                NhanVien nv = new NhanVien();
                nv.setTen(rs.getString("tennv"));
                dh.setNhanvien(nv);
                
                dh.setId(rs.getInt("id_ddh"));
                dh.setNgaylap(rs.getDate("ngaylap"));
                dh.setTonggia(rs.getInt("tonggia"));
                dh.setTinhtrang(rs.getString("tinhtrang"));
                dh.setGhichu(rs.getString("ghichu"));
                listDonHang.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseResultSet(rs);
            DatabaseUtils.CloseStatement(sta);
            DatabaseUtils.CloseConnection(con);
        }
        return listDonHang;
    }

    public static String updateDonHang(String ghichu, String id, String tinhtrang) {
        String sql = "update tbl_dondathang set tinhtrang=N'" + tinhtrang + "', ghichu=N'" + ghichu + "' where id=" + id;
        Connection con = null;
        Statement state = null;
        try {
            con = DatabaseUtils.getConnection();
            state = con.createStatement();
            state.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
        return sql;
    }
    
}
