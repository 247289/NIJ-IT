/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import utils.DatabaseUtils;

/**
 *
 * @author Administrator
 */
public class DienThoaiDAO {

    public static ArrayList<DienThoai> listDienThoai(int id) {
        ArrayList<DienThoai> listDienThoai = new ArrayList<DienThoai>();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        DienThoai dt = null;
        try {
            con = DatabaseUtils.getConnection();
            String sql = "select * from tbl_sanpham where id_dm=" + id;

            sta = con.createStatement();
            rs = sta.executeQuery(sql);

            while (rs.next()) {
                dt = new DienThoai();

                dt.setId(rs.getInt("id"));
                dt.setId_dm(rs.getInt("id_dm"));
                dt.setTen(rs.getString("ten"));
                dt.setGia(rs.getInt("gia"));
                dt.setSoluong(rs.getInt("soluong"));
                dt.setTrongluong(rs.getString("trongluong"));
                dt.setROM(rs.getString("ROM"));
                dt.setRAM(rs.getString("RAM"));
                dt.setThenho(rs.getString("thenho"));
                dt.setCamera_truoc(rs.getString("camera_truoc"));
                dt.setCamera_sau(rs.getString("camera_sau"));
                dt.setPin(rs.getInt("pin"));
                dt.setBaohanh(rs.getString("baohanh"));
                dt.setBluetooth(rs.getInt("bluetooth"));
                dt.setId_nsx(rs.getInt("id_nsx"));
                dt.setCPU(rs.getString("CPU"));
                dt.setManhinh(rs.getString("manhinh"));
                dt.setStatus(rs.getInt("status"));

                listDienThoai.add(dt);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseConnection(con);
            DatabaseUtils.CloseStatement(sta);
            DatabaseUtils.CloseResultSet(rs);
        }

        return listDienThoai;
    }

    public static ArrayList<Anh> getAnh(int id) {
        ArrayList<Anh> list = new ArrayList<Anh>();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        try {
            String sql = "select link from tbl_anh where id_sp=" + id;
            con = DatabaseUtils.getConnection();
            sta = con.createStatement();
            rs = sta.executeQuery(sql);

            while (rs.next()) {
                Anh a = new Anh();
                a.setLink(rs.getString("link"));
                list.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static DienThoai GetPhone(String id) {
        String sql = "select p.*,d.ten loai,n.ten ncc"
                + " from tbl_sanpham p,tbl_nhasanxuat n,tbl_danhmuc d"
                + " where p.id_dm=d.id and p.id_nsx=n.id and p.id=" + id;
        Connection con = null;
        Statement state = null;
        ResultSet rs = null;
        DienThoai dt = null;
        try {
            con = DatabaseUtils.getConnection();
            state = con.createStatement();
            rs = state.executeQuery(sql);
            while (rs.next()) {
                dt = new DienThoai();

                NhaSanXuat nsx = new dto.NhaSanXuat();
                nsx.setTen(rs.getString("ncc"));
                dt.setNsx(nsx);

                DanhMuc dmuc = new DanhMuc();
                dmuc.setTen(rs.getString("loai"));
                dt.setDanhmuc(dmuc);

                dt.setId(rs.getInt("id"));
                dt.setTen(rs.getString("ten"));
                dt.setGia(rs.getInt("gia"));
                dt.setSoluong(rs.getInt("soluong"));
                dt.setTrongluong(rs.getString("trongluong"));
                dt.setROM(rs.getString("ROM"));
                dt.setRAM(rs.getString("RAM"));
                dt.setThenho(rs.getString("thenho"));
                dt.setCamera_truoc(rs.getString("camera_truoc"));
                dt.setCamera_sau(rs.getString("camera_sau"));
                dt.setPin(rs.getInt("pin"));
                dt.setBaohanh(rs.getString("baohanh"));
                dt.setBluetooth(rs.getInt("bluetooth"));
                dt.setCPU(rs.getString("CPU"));
                dt.setManhinh(rs.getString("manhinh"));
                dt.setStatus(rs.getInt("status"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseResultSet(rs);
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
        return dt;
    }

    /* Thêm sản phẩm */
    public static boolean InsertPhone(String id_dm, String ten, String gia, String soluong, String trongluong, String rom, String ram, String thenho, String camera_truoc, String camera_sau, String pin, String baohanh, String bluetooth, String id_nsx, String cpu, String manhinh, String[] ha, String status) {
        String sql = "INSERT INTO dbo.tbl_sanpham VALUES  ( " + id_dm + " ,  N'" + ten + "' , " + gia + " , " + soluong + " , N'" + trongluong + "' , N'" + rom + "' , N'" + ram + "' , N'" + thenho + "' , N'" + camera_truoc + "' , N'" + camera_sau + "' , " + pin + " , N'" + baohanh + "' , " + bluetooth + " , " + id_nsx + " , '" + cpu + "' , N'" + manhinh + "' , " + status + " )";
        Connection con = null;
        Statement state = null;
        boolean isvalid = false;
        try {
            con = DatabaseUtils.getConnection();
            state = con.createStatement();
            state.executeUpdate(sql);
            int id_sp = getId_sp(ten);
            for (int i = 0; i < ha.length; i++) {
                themAnh(ha[i], id_sp);
            }
            isvalid = true;
        } catch (Exception e) {
//            e.printStackTrace();
            isvalid = false;
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
        return isvalid;
    }

    public static void themAnh(String link, int id_sp) {
        Connection con = null;
        Statement state = null;
        String sql = "insert into tbl_anh values('" + link + "', " + id_sp + ")";
        try {
            con = DatabaseUtils.getConnection();
            state = con.createStatement();
            state.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
    }

    public static int getId_sp(String tensp) {
        Connection con = null;
        Statement state = null;
        ResultSet rs = null;
        String sql = "exec GetId_sp N'" + tensp + "'";
        int id_sp = 0;
        try {
            con = DatabaseUtils.getConnection();
            state = con.createStatement();
            rs = state.executeQuery(sql);
            while (rs.next()) {
                id_sp = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
        return id_sp;
    }

    /*-----------------------------------*/
    
    /*Update sản phẩm*/
    public static String UpdatePhone(String ten, String gia, String soluong, String trongluong, String rom, String ram, String thenho, String ctruoc, String csau, String pin, String baohanh, String bluetooth, String cpu, String manhinh, String id_sp) {
        String sql = "UPDATE dbo.tbl_sanpham SET ten = N'"+ten+"', gia = "+gia+", soluong = "+soluong+", trongluong = "+trongluong+", rom= N'"+rom+"', ram=N'"+ram+"', thenho = N'"+thenho+"', camera_truoc = N'"+ctruoc+"', camera_sau = N'"+csau+"', pin = "+pin+", baohanh = N'"+baohanh+"', bluetooth = "+bluetooth+", CPU = N'"+cpu+"', manhinh = N'"+manhinh+"', status = 0 WHERE id_sp="+id_sp;
        System.out.println(sql);
        Connection con = null;
        Statement state = null;
        try {
            con = DatabaseUtils.getConnection();
            state = con.createStatement();
            state.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
        return sql;
    }

    /*-----------------------------------*/
    
    public static List<NhaSanXuat> GetNameNSX() {

        ArrayList<dto.NhaSanXuat> lstNSX = new ArrayList<dto.NhaSanXuat>();
        String sql = "select * from tbl_nhasanxuat";
        Connection conn = null;
        Statement state = null;
        try {
            conn = DatabaseUtils.getConnection();
            state = conn.createStatement();
            ResultSet rs = state.executeQuery(sql);
            while (rs.next()) {
                dto.NhaSanXuat nsx = new dto.NhaSanXuat();
                nsx.setId(rs.getInt("id"));
                nsx.setTen(rs.getString("ten"));

                lstNSX.add(nsx);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(conn);
        }

        return lstNSX;
    }

    public static List<DanhMuc> GetNameDM() {

        ArrayList<DanhMuc> lstDM = new ArrayList<DanhMuc>();
        String sql = "select * from tbl_danhmuc";
        Connection conn = null;
        Statement state = null;
        try {
            conn = DatabaseUtils.getConnection();
            state = conn.createStatement();
            ResultSet rs = state.executeQuery(sql);
            while (rs.next()) {
                DanhMuc dm = new DanhMuc();
                dm.setId(rs.getInt("id"));
                dm.setTen(rs.getString("ten"));

                lstDM.add(dm);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(conn);
        }

        return lstDM;
    }

    public static void main(String[] args) {
        System.out.println(getId_sp("iphone xs max"));
    }
}
