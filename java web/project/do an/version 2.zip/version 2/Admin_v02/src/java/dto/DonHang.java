/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author Administrator
 */
public class DonHang {
    private int id;
    private int id_kh;
    private int id_nv;
    private Date ngaylap;
    private int tonggia;
    private String tinhtrang;
    private String ghichu;
    private KhachHang khachhang;
    private NhanVien nhanvien;    
    private NguoiNhan nguoinhan;   
    private NhaSanXuat nsx;   
    private DanhMuc dm;   
    private DienThoai dt;   
    private ChiTietDonHang ctdh;   

    public ChiTietDonHang getCtdh() {
        return ctdh;
    }

    public void setCtdh(ChiTietDonHang ctdh) {
        this.ctdh = ctdh;
    }
    
    public DienThoai getDt() {
        return dt;
    }

    public void setDt(DienThoai dt) {
        this.dt = dt;
    }

    public DanhMuc getDm() {
        return dm;
    }

    public void setDm(DanhMuc dm) {
        this.dm = dm;
    }

    public NhaSanXuat getNsx() {
        return nsx;
    }

    public void setNsx(NhaSanXuat nsx) {
        this.nsx = nsx;
    }

    public NguoiNhan getNguoinhan() {
        return nguoinhan;
    }

    public void setNguoinhan(NguoiNhan nguoinhan) {
        this.nguoinhan = nguoinhan;
    }

    public KhachHang getKhachhang() {
        return khachhang;
    }

    public void setKhachhang(KhachHang khachhang) {
        this.khachhang = khachhang;
    }

    public NhanVien getNhanvien() {
        return nhanvien;
    }

    public void setNhanvien(NhanVien nhanvien) {
        this.nhanvien = nhanvien;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_kh() {
        return id_kh;
    }

    public void setId_kh(int id_kh) {
        this.id_kh = id_kh;
    }

    public int getId_nv() {
        return id_nv;
    }

    public void setId_nv(int id_nv) {
        this.id_nv = id_nv;
    }

    public Date getNgaylap() {
        return ngaylap;
    }

    public void setNgaylap(Date ngaylap) {
        this.ngaylap = ngaylap;
    }

    public int getTonggia() {
        return tonggia;
    }

    public void setTonggia(int tonggia) {
        this.tonggia = tonggia;
    }

    public String getTinhtrang() {
        return tinhtrang;
    }

    public void setTinhtrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
}
