/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import dto.Khachhang;
import dto.TaiKhoan;
import java.sql.*;
import java.util.Properties;
import java.util.logging.*;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import utils.DatabaseUtils;

/**
 *
 * @author Admin
 */
public class TaiKhoanDao {

    public static Khachhang checkLogin(String email, String pass) {
        Khachhang kh = null;
        Connection con = null;
        Statement state = null;
        ResultSet rs = null;
        String sql = "select * from tbl_khachhang where email='" + email + "' and matkhau='" + pass + "'";
        try {
            con = new DatabaseUtils().getConnection();
            state = con.createStatement();
            rs = state.executeQuery(sql);
            if (rs.next()) {
                kh = new Khachhang();
                kh.setId(rs.getInt("id"));
                kh.setTen(rs.getString("ten"));                
                kh.setSdt(rs.getInt("sdt"));
                kh.setMatkhau(rs.getString("matkhau"));
                kh.setEmail(rs.getString("email"));
                kh.setDiachi(rs.getString("diachi"));
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseResultSet(rs);
            DatabaseUtils.CloseConnection(con);
        }
        return kh;
    }

    // kiểm tra email tồn tại chưa
    public static boolean checkEmail(String email) {
        Connection connection = DatabaseUtils.getConnection();
        String sql = "SELECT * FROM tbl_khachhang WHERE email = '" + email + "'";
        PreparedStatement ps;
        try {
            ps = connection.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                connection.close();
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    /*
    to: người nhận
    subject: tên mail
    mess: nội dung
    */
    public static boolean sendMail(String form, String to, String subject, String mess) {
        boolean isValied = false;
        try {
            // Tạo đối tượng Email
            Properties p = new Properties();
            p.put("mail.smtp.auth", "true");
            p.put("mail.smtp.starttls.enable", "true");
            p.put("mail.smtp.host", "smtp.gmail.com");
            p.put("mail.smtp.port", 587);

            // Tạo đối tượng Session (phiên làm việc)
            Session s = Session.getInstance(p,
                    new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("letuan28091997@gmail.com", "Tuan2809");
                }
            });

            // Tạo đối tượng messeage
            Message msg = new MimeMessage(s);
            msg.setFrom(new InternetAddress(form));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            msg.setSubject(subject);
            msg.setText(mess);

            // Gửi email
            Transport.send(msg);

            isValied = true;
        } catch (Exception e) {
            isValied = false;
        }
        return isValied;
    }
    public static String insertkhachhang(String ten, String sdt, String matkhau, String email, String diachi) {
        String sql = "insert into tbl_khachhang(ten,sdt,matkhau,email,diachi) values(\'" + ten + "\'," + sdt + ",\'" + matkhau + "\',\'" + email + "\',\'" + diachi + "\')";
        Connection con = null;
        Statement state = null;
        try {
            con = new DatabaseUtils().getConnection();
            state = con.createStatement();
            state.executeUpdate(sql);
        } catch (Exception e) {
            return sql;
        } finally {
            DatabaseUtils.CloseStatement(state);
            DatabaseUtils.CloseConnection(con);
        }
        return sql;
    }

}
