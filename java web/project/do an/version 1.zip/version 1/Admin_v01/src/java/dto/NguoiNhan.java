    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Administrator
 */
public class NguoiNhan {
    private int id;
    private String ten;
    private String sdt;
    private String diachi1;
    private String diachi2;
    private String diachi3;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiachi1() {
        return diachi1;
    }

    public void setDiachi1(String diachi1) {
        this.diachi1 = diachi1;
    }

    public String getDiachi2() {
        return diachi2;
    }

    public void setDiachi2(String diachi2) {
        this.diachi2 = diachi2;
    }

    public String getDiachi3() {
        return diachi3;
    }

    public void setDiachi3(String diachi3) {
        this.diachi3 = diachi3;
    }
    
    
}
