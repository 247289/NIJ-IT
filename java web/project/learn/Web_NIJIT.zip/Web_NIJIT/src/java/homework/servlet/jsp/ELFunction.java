package homework.servlet.jsp;


public class ELFunction {
    public static int sum(int a, int b){
        return a+b;
    }
    public static int minus(int a, int b){
        return a-b;
    }
}
